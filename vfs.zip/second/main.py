print("OS Emulator")
